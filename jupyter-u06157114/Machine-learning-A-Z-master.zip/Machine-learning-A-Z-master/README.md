# Machine-learning A-Z
Repository for the code created during the [Udemy Machine Learning A-Z course](https://www.udemy.com/machinelearning/learn/v4/overview). 

## The course
The course features examples in R and in Python, but I've only done the Python examples so far. For some of the examples I have also added .NET versions using the [Accord.NET](http://accord-framework.net/) framework.
