﻿namespace SimpleLinearRegressionModel {
    public class SprintDataRow {
        public int NumberOfHours { get; set; }
        public double NumberOfProcessedStoryPoints { get; set; }
    }
}