﻿namespace LogisticRegressionExample {
    public class SubstanceData {
        public int Type { get; set; }
        public double Concentration { get; set; }
        public bool IsDangerous { get; set; }
    }
}