﻿namespace LanguageProcessing {
    public class RestaurantReview {
        public string Review { get; set; }
        public bool IsPositive { get; set; }
        public bool? Prediction { get; set; }
    }
}